package com.example.padeldef;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public class AuthenticationActivity extends AppCompatActivity {

    private static final String TAG = "AuthenticationActivity";
    private EditText editTextEmail, editTextPassword, editTextFirstName, editTextLastName;
    private Button buttonRegister, buttonLogin;
    private TextView textViewSwitchToLogin, textViewSwitchToRegister;
    private ProgressBar progressBar;
    private FirebaseManager firebaseManager;
    private boolean isLoginMode = true; // Inizia in modalità login
    private TextView titleAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authentication);

        // Inizializza FirebaseManager
        firebaseManager = new FirebaseManager();

        // Inizializza le viste
        titleAuth = findViewById(R.id.titleAuth);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextFirstName = findViewById(R.id.editTextFirstName);
        editTextLastName = findViewById(R.id.editTextLastName);
        buttonRegister = findViewById(R.id.buttonRegister);
        buttonLogin = findViewById(R.id.buttonLogin);
        textViewSwitchToLogin = findViewById(R.id.textViewSwitchToLogin);
        textViewSwitchToRegister = findViewById(R.id.textViewSwitchToRegister);
        progressBar = findViewById(R.id.progressBar);

        // Imposta la visibilità iniziale
        editTextFirstName.setVisibility(View.GONE);
        editTextLastName.setVisibility(View.GONE);
        buttonRegister.setVisibility(View.GONE);

        // Listener per il pulsante di registrazione
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

        // Listener per il pulsante di login
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });

        // Listener per il testo "Switch to Register"
        textViewSwitchToRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchToRegisterMode();
            }
        });

        // Listener per il testo "Switch to Login"
        textViewSwitchToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchToLoginMode();
            }
        });
    }

    private void registerUser() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String firstName = editTextFirstName.getText().toString().trim();
        String lastName = editTextLastName.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password) ||
                TextUtils.isEmpty(firstName) || TextUtils.isEmpty(lastName)) {
            Toast.makeText(this, "Per favore, compila tutti i campi.", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        firebaseManager.createUser(email, password, new OnCompleteListener <AuthResult> () {
            @Override
            public void onComplete(@NonNull Task < AuthResult > task) {
                progressBar.setVisibility(View.GONE);
                if (task.isSuccessful()) {
                    // Creazione utente avvenuta con successo, ora salva le informazioni aggiuntive
                    FirebaseUser firebaseUser = firebaseManager.getCurrentUser();
                    if (firebaseUser != null) {
                        User user = new User(firstName, lastName, email);
                        firebaseManager.saveUser(user);

                        Toast.makeText(AuthenticationActivity.this, "Registrazione avvenuta con successo.",
                                Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(AuthenticationActivity.this, MainActivity.class)); // Reindirizza alla MainActivity
                        finish();
                    }
                } else {
                    // Se la registrazione fallisce, visualizza un messaggio all'utente.
                    Log.w(TAG, "createUserWithEmail:failure", task.getException());
                    Toast.makeText(AuthenticationActivity.this, "Registrazione fallita: " + task.getException()
                                    .getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void loginUser() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Per favore, inserisci email e password.", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);

        firebaseManager.signInUser(email, password, new OnCompleteListener < AuthResult > () {
            @Override
            public void onComplete(@NonNull Task < AuthResult > task) {
                progressBar.setVisibility(View.GONE);
                if (task.isSuccessful()) {
                    // Login avvenuto con successo
                    Toast.makeText(AuthenticationActivity.this, "Login avvenuto con successo.",
                            Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(AuthenticationActivity.this, MainActivity.class)); // Reindirizza alla MainActivity
                    finish();
                } else {
                    // Se il login fallisce, visualizza un messaggio all'utente.
                    Log.w(TAG, "signInWithEmail:failure", task.getException());
                    Toast.makeText(AuthenticationActivity.this, "Login fallito: " + task.getException()
                                    .getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void switchToRegisterMode() {
        isLoginMode = false;
        editTextFirstName.setVisibility(View.VISIBLE);
        editTextLastName.setVisibility(View.VISIBLE);
        buttonRegister.setVisibility(View.VISIBLE);
        buttonLogin.setVisibility(View.GONE);
        textViewSwitchToLogin.setVisibility(View.VISIBLE);
        textViewSwitchToRegister.setVisibility(View.GONE);
    }

    private void switchToLoginMode() {
        isLoginMode = true;
        editTextFirstName.setVisibility(View.GONE);
        editTextLastName.setVisibility(View.GONE);
        buttonRegister.setVisibility(View.GONE);
        buttonLogin.setVisibility(View.VISIBLE);
        textViewSwitchToLogin.setVisibility(View.GONE);
        textViewSwitchToRegister.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Verifica se l'utente è già loggato
        FirebaseUser currentUser = firebaseManager.getCurrentUser();
        if (currentUser != null) {
            startActivity(new Intent(AuthenticationActivity.this, MainActivity.class));
            finish();
        }
    }
}
