package com.example.padeldef;

public class Invitation {
    private String inviterId;
    private String inviteeId;
    private int courtNumber;
    private String courtId;
    private String bookingDateTime;

    public Invitation() {}

    public Invitation(String inviterId, String inviteeId, int courtNumber, String courtId, String bookingDateTime) {
        this.inviterId = inviterId;
        this.inviteeId = inviteeId;
        this.courtNumber = courtNumber;
        this.courtId = courtId;
        this.bookingDateTime = bookingDateTime;
    }

    // Getters and setters

    public String getInviterId() {
        return inviterId;
    }

    public void setInviterId(String inviterId) {
        this.inviterId = inviterId;
    }

    public String getInviteeId() {
        return inviteeId;
    }

    public void setInviteeId(String inviteeId) {
        this.inviteeId = inviteeId;
    }

    public String getCourtId() {
        return courtId;
    }

    public void setCourtId(String courtId) {
        this.courtId = courtId;
    }

    public String getBookingDateTime() {
        return bookingDateTime;
    }

    public void setBookingDateTime(String bookingDateTime) {
        this.bookingDateTime = bookingDateTime;
    }

    public int getCourtNumber() {
        return this.courtNumber;
    }
}
