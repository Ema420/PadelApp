package com.example.padeldef;

import java.util.Map;

public class Instructor {
    private String instructorId;
    private String name;
    private Map<String, Map<String, Boolean>> availability; // Map<Giorno, Map<Ora, Disponibilità>>
    private int lessonsGiven;

    public Instructor() {}

    public String getInstructorId() {
        return instructorId;
    }
    public void setInstructorId(String instructorId) {
        this.instructorId = instructorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<String, Map<String, Boolean>> getAvailability() {
        return availability;
    }
    public void setAvailability(Map<String, Map<String, Boolean>> availability) {
        this.availability = availability;
    }

    public int getLessonsGiven() {
        return lessonsGiven;
    }
    public void setLessonsGiven(int lessonsGiven) {
        this.lessonsGiven = lessonsGiven;
    }

}