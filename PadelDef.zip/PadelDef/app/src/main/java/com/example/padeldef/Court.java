package com.example.padeldef;

import java.util.HashMap;
import java.util.Map;

public class Court {
    private String courtId;
    private int courtNumber;
    private String type; // Indoor or Outdoor
    private Map < String, String > bookings; // Date and Time -> Status

    public Court() {
        // Required empty constructor for Firebase
        bookings = new HashMap < > ();
    }

    public Court(int courtNumber, String type) {
        this.courtNumber = courtNumber;
        this.type = type;
        this.bookings = new HashMap < > ();
    }

    // Method to get the status for a specific date and time
    public String getStatus(String dateTime) {
        return bookings.getOrDefault(dateTime, "AVAILABLE");
    }

    // Method to set the status for a specific date and time
    public void setStatus(String dateTime, String status) {
        bookings.put(dateTime, status);
    }

    // Getter and setter methods for all fields
    public String getCourtId() {
        return courtId;
    }
    public void setCourtId(String courtId) {
        this.courtId = courtId;
    }
    public int getCourtNumber() {
        return courtNumber;
    }
    public void setCourtNumber(int courtNumber) {
        this.courtNumber = courtNumber;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }

    public Map < String, String > getBookings() {
        return bookings;
    }

    public void setBookings(Map < String, String > bookings) {
        this.bookings = bookings;
    }
}
