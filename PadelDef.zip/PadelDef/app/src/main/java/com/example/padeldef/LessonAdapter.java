package com.example.padeldef;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.List;


public class LessonAdapter extends ArrayAdapter<Lesson> {


    private Context context;
    private List<Lesson> lessons;
    private String userId;
    private boolean showRemoveButton = false;
    private DatabaseReference instructorsRef, lessonsRef;


    public LessonAdapter(Context context, List<Lesson> lessons, String userId) {
        super(context, 0, lessons);
        this.context = context;
        this.lessons = lessons;
        this.userId = userId;
        this.instructorsRef = FirebaseDatabase.getInstance().getReference("instructors");
        this.lessonsRef = FirebaseDatabase.getInstance().getReference("lessons");
    }


    public void setShowRemoveButton(boolean showRemoveButton) {
        this.showRemoveButton = showRemoveButton;
        notifyDataSetChanged(); // Refresh the list when the button visibility changes
    }


    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        Lesson lesson = getItem(position);


        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.lesson_item, parent, false);
        }


        TextView lessonInfoTextView = convertView.findViewById(R.id.lessonInfoTextView);
        lessonInfoTextView.setTextSize(16);
        ImageButton removeButton = convertView.findViewById(R.id.removeButton);


        // Fetch instructor name
        instructorsRef.child(lesson.getInstructorId()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Instructor instructor = dataSnapshot.getValue(Instructor.class);
                    if (instructor != null) {
                        // Populate the lesson info with instructor name
                        String lessonInfo = "Istruttore: " + instructor.getName() +
                                "\nData e Ora: " + lesson.getLessonDate();
                        lessonInfoTextView.setText(lessonInfo);
                    } else {
                        // Handle the case where instructor data is not available
                        lessonInfoTextView.setText("Instructor data not available");
                    }
                } else {
                    // Handle the case where instructor data is not available
                    lessonInfoTextView.setText("Instructor data not found");
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("LessonAdapter", "Error fetching instructor data: " + databaseError.getMessage());
                lessonInfoTextView.setText("Error fetching instructor data");
            }
        });


        // Set visibility of the remove button
        removeButton.setVisibility(showRemoveButton ? View.VISIBLE : View.GONE);


        removeButton.setOnClickListener(v -> {
            // Handle the removal of the lesson
            removeLesson(lesson);
        });


        return convertView;
    }


    private void removeLesson(Lesson lesson) {
        // Remove the lesson from Firebase
        lessonsRef.orderByChild("userId").equalTo(userId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            Lesson dbLesson = snapshot.getValue(Lesson.class);
                            if (dbLesson != null &&
                                    dbLesson.getLessonDate().equals(lesson.getLessonDate()) &&
                                    dbLesson.getLessonTime().equals(lesson.getLessonTime()) &&
                                    dbLesson.getInstructorId().equals(lesson.getInstructorId()) &&
                                    dbLesson.getCourtId().equals(lesson.getCourtId())) {
                                // Remove the lesson
                                String lessonKey = snapshot.getKey();
                                lessonsRef.child(lessonKey).removeValue()
                                        .addOnSuccessListener(aVoid -> {
                                            // Decrement the instructor's lessonsGiven
                                            decrementLessonsGiven(lesson.getInstructorId());
                                            // Remove availability
                                            removeAvailability(lesson.getInstructorId(), lesson.getLessonDate());
                                            // Remove from the list and update the adapter
                                            lessons.remove(lesson);
                                            notifyDataSetChanged();
                                            Toast.makeText(context, "Lesson removed successfully!", Toast.LENGTH_SHORT).show();
                                        })
                                        .addOnFailureListener(e -> {
                                            Toast.makeText(context, "Error removing lesson: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                        });
                                break;
                            }
                        }
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e("LessonAdapter", "Error finding lesson: " + databaseError.getMessage());
                    }
                });
    }


    private void decrementLessonsGiven(String instructorId) {
        DatabaseReference instructorRef = FirebaseDatabase.getInstance().getReference("instructors").child(instructorId);
        instructorRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Instructor instructor = dataSnapshot.getValue(Instructor.class);
                    if (instructor != null) {
                        int currentLessonsGiven = instructor.getLessonsGiven();
                        if (currentLessonsGiven > 0) {
                            instructorRef.child("lessonsGiven").setValue(currentLessonsGiven - 1)
                                    .addOnSuccessListener(aVoid -> Log.d("LessonAdapter", "Lessons given decremented successfully for instructor " + instructorId))
                                    .addOnFailureListener(e -> Log.e("LessonAdapter", "Error decrementing lessons given for instructor " + instructorId + ": " + e.getMessage()));
                        }
                    }
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("LessonAdapter", "Error retrieving instructor information: " + databaseError.getMessage());
            }
        });
    }


    private void removeAvailability(String instructorId, String lessonDateTime) {
        DatabaseReference availabilityRef = instructorsRef.child(instructorId).child("availability").child(lessonDateTime);
        availabilityRef.removeValue()
                .addOnSuccessListener(aVoid -> Log.d("LessonAdapter", "Availability removed successfully for instructor " + instructorId + " at " + lessonDateTime))
                .addOnFailureListener(e -> Log.e("LessonAdapter", "Error removing availability for instructor " + instructorId + " at " + lessonDateTime + ": " + e.getMessage()));
    }
}
