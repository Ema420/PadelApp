package com.example.padeldef;

import java.util.ArrayList;
import java.util.List;

public class User {

    private boolean admin;
    private String userId;
    private String firstName;
    private String lastName;
    private String profileImageURL;
    private String email;
    private String bio;
    private float reputation;
    private int ranking;
    private List< String > reportsReceived;
    private int numbersOfReview;

    public User() {
        // Required empty constructor for Firebase
    }

    public User(String firstName, String lastName, String profileImageURL, String email, String bio, int numbersOfReview) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.profileImageURL = profileImageURL;
        this.email = email;
        this.bio = bio;
        this.numbersOfReview = numbersOfReview;
        this.reputation = 0.0F;
        this.ranking = 1000;
        this.reportsReceived = new ArrayList< >();
    }

    public User(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.numbersOfReview = 0;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }



    // Getter and setter methods for all fields
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getProfileImageURL() {
        return profileImageURL;
    }
    public void setProfileImageURL(String profileImageURL) {
        this.profileImageURL = profileImageURL;
    }
    public String getBio() {
        return bio;
    }
    public void setBio(String bio) {
        this.bio = bio;
    }
    public float getReputation() {
        return reputation;
    }
    public void setReputation(float reputation) {
        this.reputation = reputation;
    }
    public int getRanking() {
        return ranking;
    }
    public void setRanking(int ranking) {
        this.ranking = ranking;
    }
    public List < String > getReportsReceived() {
        return reportsReceived;
    }
    public void setReportsReceived(List < String > reportsReceived) {
        this.reportsReceived = reportsReceived;
    }

    public String getEmail() {
        return email;
    }

    public int getNumbersOfReview() {
        return numbersOfReview;
    }

    public void setNumbersOfReview(int numbersOfReview) {
        this.numbersOfReview = numbersOfReview;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }
}

