package com.example.padeldef;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment {

    private static final String TAG = "HomeFragment";
    private RecyclerView courtsRecyclerView;
    private CourtAdapter courtAdapter;
    private List<Court> courtList = new ArrayList<>();
    private FirebaseManager firebaseManager;
    private FirebaseAuth mAuth;
    private boolean isAdmin = false;
    private Button addCourtButton;
    private String selectedDate;
    private TextView selectedDateText;
    private ImageButton openDatePickerButton; // ImageButton to open the DatePickerDialog

    private InvitationManager invitationManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        invitationManager = new InvitationManager(getContext());

        courtsRecyclerView = view.findViewById(R.id.courtsRecyclerView);
        courtsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        selectedDateText = view.findViewById(R.id.selectedDateText);
        openDatePickerButton = view.findViewById(R.id.openDatePickerButton); // Initialize the button

        firebaseManager = new FirebaseManager();
        mAuth = FirebaseAuth.getInstance();

        addCourtButton = view.findViewById(R.id.addCourtButton);

        // Initialize selectedDate with current date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        selectedDate = dateFormat.format(new Date());
        selectedDateText.setText("Data selezionata: " + selectedDate);

        checkAdminStatus();
        loadCourtsForSelectedDate(selectedDate);

        // Set onClickListener for the openDatePickerButton
        openDatePickerButton.setOnClickListener(v -> {
            showDatePickerDialog();
        });

        return view;
    }

    private void showDatePickerDialog() {
        // Get current date
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        // Create DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(),
                (view, year1, monthOfYear, dayOfMonth) -> {
                    // Update selectedDate and display it
                    Calendar calendar = Calendar.getInstance();
                    calendar.set(year1, monthOfYear, dayOfMonth);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    selectedDate = dateFormat.format(calendar.getTime());
                    selectedDateText.setText("Data selezionata: " + selectedDate);
                    loadCourtsForSelectedDate(selectedDate);
                }, year, month, day);

        // Show DatePickerDialog
        datePickerDialog.show();
    }

    private void loadCourtsForSelectedDate(String date) {
        firebaseManager.getCourts(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                courtList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Court court = snapshot.getValue(Court.class);
                    if (court != null) {
                        court.setCourtId(snapshot.getKey());
                        courtList.add(court);
                    }
                }
                courtAdapter = new CourtAdapter(courtList, HomeFragment.this::onCourtClicked, date);
                courtsRecyclerView.setAdapter(courtAdapter);
                courtAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Error loading courts: " + databaseError.getMessage());
            }
        });
    }


    private void checkAdminStatus() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            String userId = user.getUid();
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(userId);
            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    User currentUser = dataSnapshot.getValue(User.class);
                    if (currentUser != null && currentUser.isAdmin()) {
                        isAdmin = true;
                        addCourtButton.setVisibility(View.VISIBLE);
                        addCourtButton.setOnClickListener(v -> showAddCourtDialog());
                    } else {
                        isAdmin = false;
                        addCourtButton.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e(TAG, "Errore nella verifica dell'admin: " + databaseError.getMessage());
                }
            });
        } else {
            addCourtButton.setVisibility(View.GONE);
        }
    }

    private void showAddCourtDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.add_court_dialog, null);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();

        Button addCourtConfirmButton = dialogView.findViewById(R.id.addCourtConfirmButton);
        EditText courtNumberEditText = dialogView.findViewById(R.id.courtNumberEditText);
        EditText courtTypeEditText = dialogView.findViewById(R.id.courtTypeEditText);

        addCourtConfirmButton.setOnClickListener(v -> {
            String courtNumberString = courtNumberEditText.getText().toString();
            String courtType = courtTypeEditText.getText().toString();

            if (!courtNumberString.isEmpty() && !courtType.isEmpty()) {
                try {
                    int courtNumber = Integer.parseInt(courtNumberString);
                    addCourtToDatabase(courtNumber, courtType);
                    dialog.dismiss();
                } catch (NumberFormatException e) {
                    Toast.makeText(getContext(), "Numero campo non valido", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), "Inserisci numero e tipo del campo", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void addCourtToDatabase(int courtNumber, String courtType) {
        DatabaseReference courtsRef = FirebaseDatabase.getInstance().getReference("courts");
        String courtId = courtsRef.push().getKey();
        Court newCourt = new Court(courtNumber, courtType);
        newCourt.setCourtId(courtId);

        courtsRef.child(courtId).setValue(newCourt)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(getContext(), "Campo aggiunto con successo!", Toast.LENGTH_SHORT).show();
                    loadCourtsForSelectedDate(selectedDate); // Reload courts for selected date
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(getContext(), "Errore nell'aggiunta del campo: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void onCourtClicked(Court court) {
        Log.d(TAG, "Campo cliccato: " + court.getCourtNumber());
        showBookingDialog(court);
    }

    private void showBookingDialog(Court court) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.booking_dialog, null);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();

        TextView selectedDateText = dialogView.findViewById(R.id.selectedDateText);
        ImageButton openDatePickerButton = dialogView.findViewById(R.id.openDatePickerButton);
        TimePicker timePicker = dialogView.findViewById(R.id.timePicker);
        Button bookButton = dialogView.findViewById(R.id.bookButton);
        Button inviteButton = dialogView.findViewById(R.id.inviteButton);

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        selectedDate = dateFormat.format(new Date());
        selectedDateText.setText("Data selezionata: " + selectedDate);

        final String[] selectedDateTime = {null}; // Array to hold selected date and time

        //Set onClickListener for the openDatePickerButton
        openDatePickerButton.setOnClickListener(v -> {
            showDatePickerDialog();
        });

        bookButton.setOnClickListener(v -> {
            int hour = timePicker.getHour();
            int minute = timePicker.getMinute();

            Calendar bookingCalendar = Calendar.getInstance();
            try {
                bookingCalendar.setTime(dateFormat.parse(selectedDate));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            bookingCalendar.set(Calendar.HOUR_OF_DAY, hour);
            bookingCalendar.set(Calendar.MINUTE, minute);

            String bookingDateTime = dateTimeFormat.format(bookingCalendar.getTime());
            attemptBooking(court, bookingDateTime, dialog);
        });

        inviteButton.setOnClickListener(v -> {
            int hour = timePicker.getHour();
            int minute = timePicker.getMinute();

            Calendar bookingCalendar = Calendar.getInstance();
            try {
                bookingCalendar.setTime(dateFormat.parse(selectedDate));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            bookingCalendar.set(Calendar.HOUR_OF_DAY, hour);
            bookingCalendar.set(Calendar.MINUTE, minute);

            String bookingDateTime = dateTimeFormat.format(bookingCalendar.getTime());
            inviteFriend(court, bookingDateTime);
        });

        dialog.show();
    }

    private void inviteFriend(Court court, String bookingDateTime) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Invita un amico");

        final EditText emailEditText = new EditText(getContext());
        emailEditText.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        builder.setView(emailEditText);

        builder.setPositiveButton("Invita", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String friendEmail = emailEditText.getText().toString();
                if (!friendEmail.isEmpty()) {
                    sendInvitation(court, bookingDateTime, friendEmail);
                } else {
                    Toast.makeText(getContext(), "Inserisci l'email dell'amico", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Annulla", (dialogInterface, i) -> dialogInterface.cancel());

        builder.show();
    }

    private void sendInvitation(Court court, String bookingDateTime, String friendEmail) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(getContext(), "Devi essere loggato per invitare un amico", Toast.LENGTH_SHORT).show();
            return;
        }
        String currentUserId = currentUser.getUid();

        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("users");
        usersRef.orderByChild("email").equalTo(friendEmail)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                User invitedUser = snapshot.getValue(User.class);
                                String invitedUserId = snapshot.getKey();

                                if (invitedUser != null) {
                                    // Create an invitation object
                                    Invitation invitation = new Invitation(
                                            currentUserId,
                                            invitedUserId,
                                            court.getCourtNumber(),
                                            court.getCourtId(),
                                            bookingDateTime
                                    );
                                    DatabaseReference invitationsRef = FirebaseDatabase.getInstance().getReference("invitations");
                                    String invitationId = invitationsRef.push().getKey();
                                    invitationsRef.child(invitationId).setValue(invitation)
                                            .addOnSuccessListener(aVoid -> Toast.makeText(getContext(), "Invito mandato con successo!", Toast.LENGTH_SHORT).show())
                                            .addOnFailureListener(e -> Toast.makeText(getContext(), "Errore mandando l'invito: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                                }
                            }
                        } else {
                            Toast.makeText(getContext(), "Utente non trovato con questa email", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e(TAG, "Errore cercando l'utente: " + databaseError.getMessage());
                    }
                });
    }

    private void attemptBooking(Court court, String bookingDateTime, AlertDialog dialog) {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            String userId = user.getUid();
            DatabaseReference bookingsRef = FirebaseDatabase.getInstance().getReference("bookings");

            bookingsRef.orderByChild("courtId").equalTo(court.getCourtId())
                    .addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            int bookingCount = 0;
                            for (DataSnapshot bookingSnapshot : dataSnapshot.getChildren()) {
                                Booking booking = bookingSnapshot.getValue(Booking.class);
                                if (booking != null && booking.getBookingTime().equals(bookingDateTime)) { // Usa bookingDateTime
                                    bookingCount++;
                                }
                            }

                            String status;
                            if (bookingCount >= 4) {
                                Toast.makeText(getContext(), "Campo non disponibile per questo orario", Toast.LENGTH_SHORT).show();
                                status = "BOOKED";
                            } else {
                                Booking newBooking = new Booking(court.getCourtId(), userId, bookingDateTime); // Usa bookingDateTime
                                String bookingId = bookingsRef.push().getKey();
                                newBooking.setBookingId(bookingId);

                                if (bookingCount == 3) {
                                    newBooking.setStatus("BOOKED");
                                    status = "BOOKED";
                                } else {
                                    newBooking.setStatus("SEMI-BOOKED");
                                    status = "SEMI-BOOKED";
                                }

                                bookingsRef.child(bookingId).setValue(newBooking)
                                        .addOnSuccessListener(aVoid -> {
                                            Toast.makeText(getContext(), "Prenotazione effettuata con successo!", Toast.LENGTH_SHORT).show();
                                            court.setStatus(bookingDateTime, status); // Usa bookingDateTime
                                            updateCourtStatus(court, bookingDateTime, status); // Usa bookingDateTime
                                            dialog.dismiss();
                                            refreshFragment();
                                        })
                                        .addOnFailureListener(e -> {
                                            Toast.makeText(getContext(), "Errore durante la prenotazione: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                        });
                                return;
                            }
                            court.setStatus(bookingDateTime, status); // Usa bookingDateTime
                            updateCourtStatus(court, bookingDateTime, status); // Usa bookingDateTime
                            dialog.dismiss();
                            refreshFragment();
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Log.e(TAG, "Errore nella ricerca delle prenotazioni: " + databaseError.getMessage());
                        }
                    });
        }
    }

    private void updateCourtStatus(Court court, String bookingDateTime, String status) {
        DatabaseReference courtsRef = FirebaseDatabase.getInstance().getReference("courts");
        courtsRef.child(court.getCourtId()).child("bookings").child(bookingDateTime).setValue(status)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Court status updated successfully in Firebase");
                    loadCourtsForSelectedDate(selectedDate); // Reload courts to reflect changes
                })
                .addOnFailureListener(e -> Log.e(TAG, "Failed to update court status in Firebase: " + e.getMessage()));
    }

    private void refreshFragment() {
        FragmentTransaction ft = getParentFragmentManager().beginTransaction();
        ft.replace(R.id.fragment_container, new HomeFragment());
        ft.commit();
    }

    @Override
    public void onResume() {
        super.onResume();
        invitationManager.listenForInvitations();
    }
}
