package com.example.padeldef;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.padeldef.R;
import com.example.padeldef.User;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter < UserAdapter.UserViewHolder > {

    private List < User > userList;
    private OnUserClickListener listener;

    public UserAdapter(List < User > userList, OnUserClickListener listener) {
        this.userList = userList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        User user = userList.get(position);
        holder.userNameTextView.setText(user.getFirstName() + " " + user.getLastName());
        //holder.userRankingTextView.setText("Ranking: " + user.getRanking());

        holder.itemView.setOnClickListener(v -> listener.onUserClicked(user));
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView userNameTextView;
        //TextView userRankingTextView;

        UserViewHolder(@NonNull View itemView) {
            super(itemView);
            userNameTextView = itemView.findViewById(R.id.userNameTextView);
            //userRankingTextView = itemView.findViewById(R.id.userRankingTextView);
        }
    }

    interface OnUserClickListener {
        void onUserClicked(User user);
    }
}
