package com.example.padeldef;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;


public class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ReportViewHolder> {


    private List<Report> reportsList;


    public ReportAdapter(List<Report> reportsList) {
        this.reportsList = reportsList;
    }


    @NonNull
    @Override
    public ReportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_2, parent, false);
        return new ReportViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull ReportViewHolder holder, int position) {
        Report report = reportsList.get(position);
        holder.bind(report);
    }


    @Override
    public int getItemCount() {
        return reportsList.size();
    }


    static class ReportViewHolder extends RecyclerView.ViewHolder {
        private TextView text1;
        private TextView text2;


        public ReportViewHolder(@NonNull View itemView) {
            super(itemView);
            text1 = itemView.findViewById(android.R.id.text1);
            text2 = itemView.findViewById(android.R.id.text2);
        }


        public void bind(Report report) {
            // Get the reporter's name from their ID
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(report.getReporterId());
            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        User reporter = snapshot.getValue(User.class);
                        if (reporter != null) {
                            String reportText = report.getReportText();
                            text1.setText("Segnalazione da: " + reporter.getFullName());
                            text2.setText(reportText);
                        } else {
                            text1.setText("Segnalazione da: Sconosciuto");
                            text2.setText(report.getReportText());
                        }
                    } else {
                        text1.setText("Segnalazione da: Sconosciuto");
                        text2.setText(report.getReportText());
                    }
                }


                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    text1.setText("Segnalazione da: Errore");
                    text2.setText("Errore nel caricamento");
                }
            });
        }
    }
}
