package com.example.padeldef;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Map;

public class CourtAdapter extends RecyclerView.Adapter < CourtAdapter.CourtViewHolder > {

    private List < Court > courtList;
    private OnCourtClickListener listener;
    private String selectedDate;
    private boolean isAdmin;
    private boolean isRemoveMode = false;
    private OnRemoveCourtListener removeCourtListener;

    public CourtAdapter(List < Court > courtList, OnCourtClickListener listener, String selectedDate, boolean isAdmin, OnRemoveCourtListener removeCourtListener) {
        this.courtList = courtList;
        this.listener = listener;
        this.selectedDate = selectedDate;
        this.isAdmin = isAdmin;
        this.removeCourtListener = removeCourtListener;
    }

    public void setRemoveMode(boolean removeMode) {
        isRemoveMode = removeMode;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CourtViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_court2, parent, false);
        return new CourtViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CourtViewHolder holder, int position) {
        Court court = courtList.get(position);
        holder.courtNumberTextView.setText("Campo " + court.getCourtNumber());
        holder.courtTypeTextView.setText(court.getType());

        // Mostra tutte le prenotazioni per il campo nella data selezionata
        StringBuilder bookingTimesText = new StringBuilder();
        String status = "AVAILABLE";

        if (court.getBookings() != null) {
            for (Map.Entry < String, String > entry: court.getBookings().entrySet()) {
                if (entry.getKey().startsWith(selectedDate)) {
                    bookingTimesText.append("Prenotato: ").append(entry.getKey().substring(11)).append(" - ").append(entry.getValue()).append("\n");
                }
            }
        }

        if (bookingTimesText.length() == 0) {
            bookingTimesText.append("Nessuna prenotazione per questa data");
            status = "AVAILABLE";
        }

        holder.courtBookingTimesTextView.setText(bookingTimesText.toString());
        holder.courtStatusTextView.setText("Stato: " + status);

        if (status.equals("BOOKED")) {
            holder.courtStatusTextView.setTextColor(Color.RED);
        } else if (status.equals("SEMI-BOOKED")) {
            holder.courtStatusTextView.setTextColor(Color.YELLOW);
        } else {
            holder.courtStatusTextView.setTextColor(Color.GREEN);
        }

        holder.itemView.setOnClickListener(v -> {
            if (!isRemoveMode) {
                listener.onCourtClicked(court);
            }
        });

        // Show remove button only in remove mode and for admins
        if (isAdmin && isRemoveMode) {
            holder.removeButton.setVisibility(View.VISIBLE);
            holder.removeButton.setOnClickListener(v -> {
                removeCourtListener.onRemoveCourt(court);
            });
        } else {
            holder.removeButton.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return courtList.size();
    }

    static class CourtViewHolder extends RecyclerView.ViewHolder {
        TextView courtNumberTextView;
        TextView courtTypeTextView;
        TextView courtStatusTextView;
        TextView courtBookingTimesTextView;
        ImageButton removeButton;

        CourtViewHolder(@NonNull View itemView) {
            super(itemView);
            courtNumberTextView = itemView.findViewById(R.id.courtNumberTextView);
            courtTypeTextView = itemView.findViewById(R.id.courtTypeTextView);
            courtStatusTextView = itemView.findViewById(R.id.courtStatusTextView);
            courtBookingTimesTextView = itemView.findViewById(R.id.courtBookingTimesTextView);
            removeButton = itemView.findViewById(R.id.removeButton);
        }
    }

    interface OnCourtClickListener {
        void onCourtClicked(Court court);
    }

    interface OnRemoveCourtListener {
        void onRemoveCourt(Court court);
    }
}
