package com.example.padeldef;

public class Lesson {
    private String lessonId;
    private String courtId;
    private String instructorId;
    private String userId;
    private String lessonTime;

    private String lessonDate;

    public Lesson() {
        // Required empty constructor for Firebase
    }

    public Lesson(String courtId, String instructorId, String userId, String lessonTime, String lessonDate) {
        this.courtId = courtId;
        this.instructorId = instructorId;
        this.userId = userId;
        this.lessonTime = lessonTime;
        this.lessonDate = lessonDate;
    }

    // Getter and setter methods for all fields

    public String getLessonId() {
        return lessonId;
    }
    public void setLessonId(String lessonId) {
        this.lessonId = lessonId;
    }
    public String getCourtId() {
        return courtId;
    }
    public void setCourtId(String courtId) {
        this.courtId = courtId;
    }
    public String getInstructorId() {
        return instructorId;
    }
    public void setInstructorId(String instructorId) {
        this.instructorId = instructorId;
    }
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    public String getLessonTime() {
        return lessonTime;
    }
    public void setLessonTime(String lessonTime) {
        this.lessonTime = lessonTime;
    }
    public String getLessonDate() {
        return lessonDate;
    }

    public void setLessonDate(String lessonDate) {
        this.lessonDate = lessonDate;
    }
}
