package com.example.padeldef;

import android.util.Log;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class FirebaseManager {

    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    private DatabaseReference mDatabaseReference;

    public FirebaseManager() {
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mDatabase.getReference();
    }

    public FirebaseUser getCurrentUser() {
        return mAuth.getCurrentUser();
    }

    public void createUser(String email, String password, OnCompleteListener<AuthResult> listener) {
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(listener);
    }

    public void signInUser(String email, String password, OnCompleteListener < AuthResult > listener) {
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(listener);
    }

    public void signOutUser() {
        mAuth.signOut();
    }

    public void saveUser(User user) {
        String userId = getCurrentUser().getUid();
        mDatabaseReference.child("users").child(userId).setValue(user);
    }

    public void getUser(String userId, ValueEventListener listener) {
        mDatabaseReference.child("users").child(userId).addListenerForSingleValueEvent(listener);
    }

    public void saveCourt(Court court) {
        String courtId = mDatabaseReference.child("courts").push().getKey();
        court.setCourtId(courtId);
        mDatabaseReference.child("courts").child(courtId).setValue(court);
    }

    public void getCourts(ValueEventListener listener) {
        mDatabaseReference.child("courts").addListenerForSingleValueEvent(listener);
    }

    public void saveBooking(Booking booking) {
        String bookingId = mDatabaseReference.child("bookings").push().getKey();
        booking.setBookingId(bookingId);
        mDatabaseReference.child("bookings").child(bookingId).setValue(booking);
    }

    public void getBookings(ValueEventListener listener) {
        mDatabaseReference.child("bookings").addListenerForSingleValueEvent(listener);
    }

    public void saveLesson(Lesson lesson) {
        String lessonId = mDatabaseReference.child("lessons").push().getKey();
        lesson.setLessonId(lessonId);
        mDatabaseReference.child("lessons").child(lessonId).setValue(lesson);
    }

    public void getLessons(ValueEventListener listener) {
        mDatabaseReference.child("lessons").addListenerForSingleValueEvent(listener);
    }

    public void reportUser(String reportedUserId, String reporterUserId, String reason) {
        DatabaseReference reportsRef = mDatabaseReference.child("reports").child(reportedUserId);
        String reportId = reportsRef.push().getKey();
        reportsRef.child(reportId).setValue(reporterUserId + ": " + reason);
    }

    public void getUserReports(String userId, ValueEventListener listener) {
        mDatabaseReference.child("reports").child(userId).addListenerForSingleValueEvent(listener);
    }

    public void updateReputation(String userId, double newReputation) {
        mDatabaseReference.child("users").child(userId).child("reputation").setValue(newReputation);
    }

    public void updateRanking(String userId, int newRanking) {
        mDatabaseReference.child("users").child(userId).child("ranking").setValue(newRanking);
    }

    // Method to fetch all users, can be used for searching and inviting
    public void getAllUsers(ValueEventListener listener) {
        mDatabaseReference.child("users").addListenerForSingleValueEvent(listener);
    }

    // Method to fetch available instructors for booking lessons
    public void getAvailableInstructors(ValueEventListener listener) {
        mDatabaseReference.child("users").orderByChild("isInstructor").equalTo(true).addListenerForSingleValueEvent(listener);
    }

    public void getUserNameById(String userId, TextView textView) {
        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("users").child(userId);
        usersRef.child("firstName").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String firstName = snapshot.getValue(String.class);

                usersRef.child("lastName").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String lastName = snapshot.getValue(String.class);
                        // Set the full name on the TextView
                        textView.setText(firstName + " " + lastName);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.e("FirebaseManager", "Error fetching user's last name: " + error.getMessage());
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseManager", "Error fetching user's first name: " + error.getMessage());
            }
        });
    }
}