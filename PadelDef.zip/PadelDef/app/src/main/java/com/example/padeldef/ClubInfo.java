package com.example.padeldef;

public class ClubInfo {
    private String name;
    private String logoUrl;
    private int numCourts;

    public ClubInfo() {
        // Required empty constructor for Firebase
    }

    public ClubInfo(String name, String logoUrl, int numCourts) {
        this.name = name;
        this.logoUrl = logoUrl;
        this.numCourts = numCourts;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLogoUrl() {
        return logoUrl;
    }

    public void setLogoUrl(String logoUrl) {
        this.logoUrl = logoUrl;
    }

    public int getNumCourts() {
        return numCourts;
    }

    public void setNumCourts(int numCourts) {
        this.numCourts = numCourts;
    }
}