package com.example.padeldef;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import com.example.padeldef.FirebaseManager;
import com.google.firebase.auth.FirebaseUser;

import androidx.appcompat.app.AppCompatActivity;

public class IntroActivity extends AppCompatActivity {

    private static final int SPLASH_DURATION = 3000; // 3 secondi

    private FirebaseManager firebaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        firebaseManager = new FirebaseManager();

        // Nasconde la barra delle azioni
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Usa un handler per ritardare l'avvio dell'attività principale
        new Handler().postDelayed(() -> {
            // Avvia l'attività principale
            firebaseManager.signOutUser();
            Intent intent = new Intent(IntroActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // Chiude l'attività introduttiva
        }, SPLASH_DURATION);
    }
}
