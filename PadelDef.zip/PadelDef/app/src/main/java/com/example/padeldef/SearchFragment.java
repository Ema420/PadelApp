package com.example.padeldef;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SearchFragment extends Fragment {

    private static final String TAG = "SearchFragment";
    private RecyclerView usersRecyclerView;
    private UserAdapter userAdapter;
    private List<User> userList = new ArrayList<>();
    private FirebaseManager firebaseManager;
    private InvitationManager invitationManager;
    private FirebaseAuth mAuth;
    private SearchView searchView; // Dichiarazione della SearchView
    private TextView titleSearch;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        firebaseManager = new FirebaseManager();
        mAuth = FirebaseAuth.getInstance();
        invitationManager = new InvitationManager(getContext());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        // Inizializzazione della SearchView
        titleSearch = view.findViewById(R.id.titleSearch);
        searchView = view.findViewById(R.id.searchView);
        searchView.setIconifiedByDefault(false);
        searchView.setQueryHint("Cerca utenti");

        usersRecyclerView = view.findViewById(R.id.usersRecyclerView);
        usersRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        userAdapter = new UserAdapter(userList, this::onUserClicked);
        usersRecyclerView.setAdapter(userAdapter);

        loadUsers();

        // Imposta il listener per la SearchView
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchUsers(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchUsers(newText);
                return true;
            }
        });

        return view;
    }

    private void loadUsers() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            Log.e(TAG, "Nessun utente loggato.");
            return;
        }
        String currentUserId = currentUser.getUid();

        firebaseManager.getAllUsers(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                userList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    User user = snapshot.getValue(User.class);
                    if (user != null) {
                        user.setUserId(snapshot.getKey());
                        if (!user.getUserId().equals(currentUserId) && (!user.isAdmin())) {
                            userList.add(user);
                        }
                    }
                }
                userAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Errore nel caricamento degli utenti: " + databaseError.getMessage());
            }
        });
    }

    private void searchUsers(String query) {
        List<User> filteredList = new ArrayList<>();
        String queryLower = query.toLowerCase(); // Converti la query in minuscolo una sola volta

        for (User user : userList) {
            String fullName = user.getFullName().toLowerCase(); // Ottieni il nome completo in minuscolo

            if (fullName.contains(queryLower)) {
                filteredList.add(user);
            }
        }

        userAdapter = new UserAdapter(filteredList, this::onUserClicked);
        usersRecyclerView.setAdapter(userAdapter);
        userAdapter.notifyDataSetChanged();
    }



    private void onUserClicked(User user) {
        Log.d(TAG, "Utente cliccato: " + user.getFirstName() + " " + user.getLastName());
        showUserProfileDialog(user);
    }

    private void showUserProfileDialog(User user) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.user_profile_dialog, null);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();

        TextView dialogUsername = dialogView.findViewById(R.id.dialogUsername);
        TextView dialogEmail = dialogView.findViewById(R.id.dialogEmail);
        TextView dialogBio = dialogView.findViewById(R.id.dialogBio);
        TextView dialogRanking = dialogView.findViewById(R.id.dialogRanking);
        TextView dialogReputation = dialogView.findViewById(R.id.dialogReputation);
        ImageView dialogImage = dialogView.findViewById(R.id.dialogImage);

        // Review elements
        RatingBar ratingBar = dialogView.findViewById(R.id.ratingBar);
        EditText reviewEditText = dialogView.findViewById(R.id.reviewEditText);
        Button submitReviewButton = dialogView.findViewById(R.id.submitReviewButton);

        dialogUsername.setText(user.getFirstName() + " " + user.getLastName());
        dialogEmail.setText(user.getEmail());
        dialogBio.setText(user.getBio());
        dialogRanking.setText("Ranking: " + user.getRanking());

        // Set initial reputation value (can be 0 if no reviews yet)
        dialogReputation.setText("Reputazione: " + user.getReputation());

        if (user.getProfileImageURL() != null && !user.getProfileImageURL().isEmpty()) {
            Glide.with(getContext())
                    .load(user.getProfileImageURL())
                    .placeholder(R.drawable.default_profile_image)
                    .error(R.drawable.error_profile_image)
                    .into(dialogImage);
        } else {
            dialogImage.setImageResource(R.drawable.default_profile_image);
        }

        RecyclerView reviewsRecyclerView = dialogView.findViewById(R.id.reviewsRecyclerView);
        reviewsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        List<Review> reviewsList = new ArrayList<>();
        ReviewAdapter reviewAdapter = new ReviewAdapter(reviewsList, firebaseManager);
        reviewsRecyclerView.setAdapter(reviewAdapter);

        // Carica le recensioni per l'utente cliccato
        loadReviews(user.getUserId(), reviewsList, reviewAdapter);

        // Submit Review Button Listener
        submitReviewButton.setOnClickListener(v -> {
            float rating = ratingBar.getRating();
            String reviewText = reviewEditText.getText().toString();
            submitReview(user, rating, reviewText, dialog, dialogReputation); // Pass the dialogReputation TextView
        });

        dialog.show();
    }

    private void submitReview(User user, float rating, String reviewText, AlertDialog dialog, TextView dialogReputation) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(getContext(), "Devi essere loggato per lasciare una recensione", Toast.LENGTH_SHORT).show();
            return;
        }
        String reviewerId = currentUser.getUid();
        String reviewedUserId = user.getUserId();

        Review review = new Review(reviewerId, reviewedUserId, rating, reviewText);

        DatabaseReference reviewsRef = FirebaseDatabase.getInstance().getReference("reviews");
        String reviewId = reviewsRef.push().getKey();
        reviewsRef.child(reviewId).setValue(review)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(getContext(), "Recensione inviata con successo!", Toast.LENGTH_SHORT).show();
                    updateUserReputation(user, rating, dialogReputation, dialog); // Pass the dialog
                })
                .addOnFailureListener(e -> Toast.makeText(getContext(), "Errore nell'invio della recensione: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void updateUserReputation(User user, float newRating, TextView dialogReputation, AlertDialog dialog) {
        // Check if user or user.getUserId() is null
        if (user == null || user.getUserId() == null) {
            Log.e(TAG, "User object or User ID is null");
            Toast.makeText(getContext(), "Errore: impossibile aggiornare la reputazione.", Toast.LENGTH_SHORT).show();
            return;  // Exit the method to prevent the error
        }

        String userId = user.getUserId();
        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(userId);

        // Get the reviews
        DatabaseReference reviewsRef = FirebaseDatabase.getInstance().getReference("reviews");
        reviewsRef.orderByChild("reviewedUserId").equalTo(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                float totalRating = 0;
                long numberOfReviews = 0;

                //Calculate the total rating
                for (DataSnapshot reviewSnapshot : snapshot.getChildren()) {
                    Review review = reviewSnapshot.getValue(Review.class);
                    if (review != null) {
                        totalRating += review.getRating();
                        numberOfReviews++;
                    }
                }

                //Calculate the new reputation
                float newReputation;
                if (numberOfReviews > 0) {
                    newReputation = totalRating / numberOfReviews;
                } else {
                    newReputation = 0;
                }

                // Update the database
                userRef.child("reputation").setValue(newReputation).addOnSuccessListener(aVoid -> {
                    dialogReputation.setText("Reputazione: " + newReputation);
                    refreshUserData(user);
                    dialog.dismiss();
                });

                //Atomically increment the number of reviews
                userRef.child("numberOfReviews").setValue(ServerValue.increment(1));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Failed to get the reviews: " + error.getMessage());
            }
        });
    }

    private void refreshUserData(User user) {
        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(user.getUserId());
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User updatedUser = snapshot.getValue(User.class);
                updatedUser.setUserId(user.getUserId());
                if (updatedUser != null) {
                    // Update the user object in the list
                    for (int i = 0; i < userList.size(); i++) {
                        if (userList.get(i).getUserId().equals(user.getUserId())) {
                            userList.set(i, updatedUser);
                            userAdapter.notifyItemChanged(i); // Notify the adapter about the change
                            break;
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Failed to refresh user data: " + error.getMessage());
            }
        });
    }

    private void loadReviews(String userId, List<Review> reviewsList, ReviewAdapter reviewAdapter) {
        DatabaseReference reviewsRef = FirebaseDatabase.getInstance().getReference("reviews");
        reviewsRef.orderByChild("reviewedUserId").equalTo(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                reviewsList.clear(); // Pulisci la lista prima di aggiungere nuove recensioni
                for (DataSnapshot reviewSnapshot : snapshot.getChildren()) {
                    Review review = reviewSnapshot.getValue(Review.class);
                    if (review != null) {
                        reviewsList.add(review); // Aggiungi la recensione alla lista
                    }
                }
                reviewAdapter.notifyDataSetChanged(); // Notifica l'adattatore della modifica dei dati
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Failed to load reviews: " + error.getMessage());
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        invitationManager.listenForInvitations();
    }
}
