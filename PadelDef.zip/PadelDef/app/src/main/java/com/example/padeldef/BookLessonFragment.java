package com.example.padeldef;


import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class BookLessonFragment extends Fragment {


    private Spinner courtSpinner, instructorSpinner, timeSpinner;
    private Button bookButton, showRemoveButton;
    private ImageButton openDatePickerButton;
    private TextView selectedDateText;
    private DatabaseReference courtsRef, instructorsRef, lessonsRef;
    private FirebaseAuth mAuth;
    private List<Court> courtList;
    private List<Instructor> instructorList;
    private List<String> timeSlots;
    private Calendar selectedDate;
    private String selectedTime;
    private ListView bookedLessonsListView;
    private List<Lesson> lessonsList = new ArrayList<>();
    private LessonAdapter lessonAdapter;
    private String userId;
    private boolean isRemoveMode = false; // Track remove mode state


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_book_lesson, container, false);


        // Initialize views
        courtSpinner = view.findViewById(R.id.courtSpinner);
        instructorSpinner = view.findViewById(R.id.instructorSpinner);
        timeSpinner = view.findViewById(R.id.timeSpinner);
        bookButton = view.findViewById(R.id.bookButton);
        openDatePickerButton = view.findViewById(R.id.openDatePickerButton);
        selectedDateText = view.findViewById(R.id.selectedDateText);
        bookedLessonsListView = view.findViewById(R.id.bookedLessonsListView);
        showRemoveButton = view.findViewById(R.id.showRemoveButton);


        // Initialize Firebase
        courtsRef = FirebaseDatabase.getInstance().getReference("courts");
        instructorsRef = FirebaseDatabase.getInstance().getReference("instructors");
        lessonsRef = FirebaseDatabase.getInstance().getReference("lessons");
        mAuth = FirebaseAuth.getInstance();
        courtList = new ArrayList<>();
        instructorList = new ArrayList<>();
        timeSlots = generateTimeSlots();
        selectedDate = Calendar.getInstance();


        // Get current user ID
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            userId = user.getUid();
        } else {
            Toast.makeText(getContext(), "User not logged in", Toast.LENGTH_SHORT).show();
            return view;
        }


        // Initialize and set LessonAdapter
        lessonAdapter = new LessonAdapter(getContext(), lessonsList, userId);
        bookedLessonsListView.setAdapter(lessonAdapter);


        // Load data
        loadCourts();
        loadInstructors();
        setupTimeSpinner();
        updateSelectedDateText();
        loadBookedLessons();


        // Listeners
        openDatePickerButton.setOnClickListener(v -> showDatePickerDialog());
        bookButton.setOnClickListener(v -> bookLesson());
        showRemoveButton.setOnClickListener(v -> toggleRemoveMode());


        return view;
    }


    // Method to toggle remove mode
    private void toggleRemoveMode() {
        isRemoveMode = !isRemoveMode;
        lessonAdapter.setShowRemoveButton(isRemoveMode);
        if(showRemoveButton.getText().equals("Rimuovi Prenotazione")){
            showRemoveButton.setText("Esci da modalita rimozione");
        } else {
            showRemoveButton.setText("Rimuovi Prenotazione");
        }
    }


    // Load courts from Firebase
    private void loadCourts() {
        courtsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                courtList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Court court = snapshot.getValue(Court.class);
                    if (court != null) {
                        court.setCourtId(snapshot.getKey());
                        courtList.add(court);
                    }
                }
                List<String> courtNames = new ArrayList<>();
                for (Court court : courtList) {
                    courtNames.add(court.getCourtNumber() + " - " + court.getType());
                }
                ArrayAdapter<String> courtAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, courtNames);
                courtAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                courtSpinner.setAdapter(courtAdapter);
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("BookLessonFragment", "Error loading courts: " + databaseError.getMessage());
            }
        });
    }


    // Load instructors from Firebase
    private void loadInstructors() {
        instructorsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                instructorList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Instructor instructor = snapshot.getValue(Instructor.class);
                    if (instructor != null) {
                        instructor.setInstructorId(snapshot.getKey());
                        instructorList.add(instructor);
                    }
                }
                List<String> instructorNames = new ArrayList<>();
                for (Instructor instructor : instructorList) {
                    instructorNames.add(instructor.getName());
                }
                ArrayAdapter<String> instructorAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, instructorNames);
                instructorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                instructorSpinner.setAdapter(instructorAdapter);
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("BookLessonFragment", "Error loading instructors: " + databaseError.getMessage());
            }
        });
    }


    // Setup time spinner
    private void setupTimeSpinner() {
        ArrayAdapter<String> timeAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, timeSlots);
        timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        timeSpinner.setAdapter(timeAdapter);
        timeSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                selectedTime = timeSlots.get(position);
            }


            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {
            }
        });
    }


    // Generate time slots
    private List<String> generateTimeSlots() {
        List<String> slots = new ArrayList<>();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 9);
        calendar.set(Calendar.MINUTE, 0);
        for (int i = 0; i < 8; i++) {
            String startTime = timeFormat.format(calendar.getTime());
            calendar.add(Calendar.HOUR_OF_DAY, 1);
            String endTime = timeFormat.format(calendar.getTime());
            slots.add(startTime + " - " + endTime);
        }
        return slots;
    }


    // Show date picker dialog
    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                getContext(),
                (view, year, month, dayOfMonth) -> {
                    selectedDate.set(year, month, dayOfMonth);
                    updateSelectedDateText();
                },
                selectedDate.get(Calendar.YEAR),
                selectedDate.get(Calendar.MONTH),
                selectedDate.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }


    // Update selected date text
    private void updateSelectedDateText() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        selectedDateText.setText("Selected Date: " + dateFormat.format(selectedDate.getTime()));
    }


    // Book a lesson
    private void bookLesson() {
        int selectedCourtIndex = courtSpinner.getSelectedItemPosition();
        int selectedInstructorIndex = instructorSpinner.getSelectedItemPosition();
        if (selectedCourtIndex < 0 || selectedInstructorIndex < 0 || selectedTime == null) {
            Toast.makeText(getContext(), "Select a court, instructor, and time.", Toast.LENGTH_SHORT).show();
            return;
        }
        Court selectedCourt = courtList.get(selectedCourtIndex);
        Instructor selectedInstructor = instructorList.get(selectedInstructorIndex);
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) {
            Toast.makeText(getContext(), "Devi essere loggato per prenotare una lezione.", Toast.LENGTH_SHORT).show();
            return;
        }
        String userId = user.getUid();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        String selectedDateString = dateFormat.format(selectedDate.getTime());
        String selectedDateTime = selectedDateString + " " + selectedTime;
        checkInstructorAvailability(selectedInstructor.getInstructorId(), selectedDateTime, isAvailable -> {
            if (isAvailable) {
                String courtId = selectedCourt.getCourtId();
                String instructorId = selectedInstructor.getInstructorId();
                Lesson newLesson = new Lesson(courtId, instructorId, userId, selectedTime, selectedDateTime);
                lessonsRef.push().setValue(newLesson)
                        .addOnSuccessListener(aVoid -> {
                            updateInstructorAvailability(instructorId, selectedDateTime, false);
                            incrementLessonsGiven(instructorId);
                            Toast.makeText(getContext(), "Lezione prenotata con successo!", Toast.LENGTH_SHORT).show();
                            loadBookedLessons();
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(getContext(), "Error booking lesson: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
            } else {
                Toast.makeText(getContext(), "Instructor not available at this time for the selected date.", Toast.LENGTH_SHORT).show();
            }
        });
    }


    // Check instructor availability
    private void checkInstructorAvailability(String instructorId, String selectedDateTime, final AvailabilityCallback callback) {
        instructorsRef.child(instructorId).child("availability")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot == null || !dataSnapshot.exists() || !dataSnapshot.hasChild(selectedDateTime)) {
                            callback.isAvailable(true);
                        } else {
                            Boolean available = dataSnapshot.child(selectedDateTime).getValue(Boolean.class);
                            if (available != null && available) {
                                callback.isAvailable(true);
                            } else {
                                callback.isAvailable(false);
                            }
                        }
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e("BookLessonFragment", "Error checking availability: " + databaseError.getMessage());
                        callback.isAvailable(false);
                    }
                });
    }


    // Update instructor availability
    private void updateInstructorAvailability(String instructorId, String selectedDateTime, boolean availability) {
        instructorsRef.child(instructorId).child("availability").child(selectedDateTime)
                .setValue(availability)
                .addOnSuccessListener(aVoid -> {
                    Log.d("BookLessonFragment", "Instructor availability updated successfully.");
                })
                .addOnFailureListener(e -> {
                    Log.e("BookLessonFragment", "Error updating instructor availability: " + e.getMessage());
                    Toast.makeText(getContext(), "Error updating instructor availability.", Toast.LENGTH_SHORT).show();
                });
    }


    // Load booked lessons
    private void loadBookedLessons() {
        lessonsList.clear();
        lessonsRef.orderByChild("userId").equalTo(userId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault());
                        Date currentDate = new Date();
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            Lesson lesson = snapshot.getValue(Lesson.class);
                            if (lesson != null) {
                                try {
                                    Date lessonDateTime = dateFormat.parse(lesson.getLessonDate());
                                    if (lessonDateTime != null && lessonDateTime.after(currentDate)) {
                                        lesson.setLessonId(snapshot.getKey());
                                        lessonsList.add(lesson);
                                    }
                                } catch (ParseException e) {
                                    Log.e("BookLessonFragment", "Error parsing date: " + e.getMessage());
                                }
                            }
                        }
                        lessonAdapter.notifyDataSetChanged();
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e("BookLessonFragment", "Error loading booked lessons: " + databaseError.getMessage());
                    }
                });
    }


    // Increment lessons given
    private void incrementLessonsGiven(String instructorId) {
        DatabaseReference instructorRef = FirebaseDatabase.getInstance().getReference("instructors").child(instructorId);
        instructorRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Instructor instructor = dataSnapshot.getValue(Instructor.class);
                    if (instructor != null) {
                        int currentLessonsGiven = instructor.getLessonsGiven();
                        instructorRef.child("lessonsGiven").setValue(currentLessonsGiven + 1)
                                .addOnSuccessListener(aVoid -> Log.d("BookLessonFragment", "Lessons given incremented successfully for instructor " + instructorId))
                                .addOnFailureListener(e -> Log.e("BookLessonFragment", "Error incrementing lessons given for instructor " + instructorId + ": " + e.getMessage()));
                    }
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("BookLessonFragment", "Error retrieving instructor information: " + databaseError.getMessage());
            }
        });
    }


    interface AvailabilityCallback {
        void isAvailable(boolean available);
    }
}
