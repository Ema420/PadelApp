package com.example.padeldef;

import androidx.fragment.app.Fragment;

public class BookLessonFragment extends Fragment {
}
