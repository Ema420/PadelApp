package com.example.padeldef;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class InvitationManager {

    private static final String TAG = "InvitationManager";
    private static final String CHANNEL_ID = "invitation_channel";
    private Context context;
    private FirebaseAuth mAuth;

    public InvitationManager(Context context) {
        this.context = context;
        this.mAuth = FirebaseAuth.getInstance();
        createNotificationChannel();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Invitation Channel";
            String description = "Channel for PadelDef invitations";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    public void listenForInvitations() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            Log.w(TAG, "No user logged in, cannot listen for invitations.");
            return;
        }
        String userId = currentUser.getUid();

        DatabaseReference invitationsRef = FirebaseDatabase.getInstance().getReference("invitations");
        invitationsRef.orderByChild("inviteeId").equalTo(userId)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot: dataSnapshot.getChildren()) {
                            Invitation invitation = snapshot.getValue(Invitation.class);
                            if (invitation != null) {
                                showInvitationNotification(invitation, snapshot.getKey());
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e(TAG, "Error listening for invitations: " + databaseError.getMessage());
                    }
                });
    }

    private void showInvitationNotification(Invitation invitation, String invitationId) {
        Intent intent = new Intent(context, InvitationActivity.class);  //TODO
        //Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra("invitationId", invitationId);
        intent.putExtra("courtNumber", invitation.getCourtNumber());
        intent.putExtra("bookingDateTime", invitation.getBookingDateTime());
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        String formattedDateTime = invitation.getBookingDateTime();

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Invito a giocare a Padel!")
                .setContentText("Sei stato invitato a giocare il " + formattedDateTime)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(invitationId.hashCode(), builder.build());
    }

    public void acceptInvitation(String invitationId) {
        DatabaseReference invitationsRef = FirebaseDatabase.getInstance().getReference("invitations");
        invitationsRef.child(invitationId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Invitation invitation = dataSnapshot.getValue(Invitation.class);
                if (invitation != null) {
                    // Attempt to book the court
                    attemptBooking(invitation);

                    // Remove the invitation after accepting
                    dataSnapshot.getRef().removeValue();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Errore accettando l'invito: " + databaseError.getMessage());
            }
        });
    }

    private void attemptBooking(Invitation invitation) {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) {
            Log.w(TAG, "No user logged in, cannot accept invitation.");
            return;
        }
        String userId = user.getUid();
        String bookingDateTime = invitation.getBookingDateTime();
        String courtId = invitation.getCourtId();

        DatabaseReference bookingsRef = FirebaseDatabase.getInstance().getReference("bookings");

        bookingsRef.orderByChild("courtId").equalTo(courtId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int bookingCount = 0;
                        for (DataSnapshot bookingSnapshot: dataSnapshot.getChildren()) {
                            Booking booking = bookingSnapshot.getValue(Booking.class);
                            if (booking != null && booking.getBookingTime().equals(bookingDateTime)) {
                                bookingCount++;
                            }
                        }

                        String status;
                        if (bookingCount >= 4) {
                            Log.w(TAG, "Court not available for this time.");
                            //TODO visualizza messaggio all'utente che il campo non è più disponibile
                            return;
                        } else {
                            Booking newBooking = new Booking(courtId, userId, bookingDateTime);
                            String bookingId = bookingsRef.push().getKey();
                            newBooking.setBookingId(bookingId);

                            if (bookingCount == 3) {
                                newBooking.setStatus("BOOKED");
                                status = "BOOKED";
                            } else {
                                newBooking.setStatus("SEMI-BOOKED");
                                status = "SEMI-BOOKED";
                            }

                            bookingsRef.child(bookingId).setValue(newBooking)
                                    .addOnSuccessListener(aVoid -> Log.d(TAG, "Booking effettuata con successo!"))
                                    .addOnFailureListener(e -> Log.e(TAG, "Errore durante la prenotazione: " + e.getMessage()));
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e(TAG, "Errore nella ricerca delle prenotazioni: " + databaseError.getMessage());
                    }
                });
    }

    public void rejectInvitation(String invitationId) {
        DatabaseReference invitationsRef = FirebaseDatabase.getInstance().getReference("invitations");
        invitationsRef.child(invitationId).removeValue()
                .addOnSuccessListener(aVoid -> Log.d(TAG, "Invito rifiutato con successo!"))
                .addOnFailureListener(e -> Log.e(TAG, "Errore rifiutando l'invito: " + e.getMessage()));
    }

}