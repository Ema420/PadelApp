package com.example.padeldef;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.RatingBar;
import android.widget.TextView;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.padeldef.FirebaseManager;
import com.example.padeldef.R;
import com.example.padeldef.Review;

import java.util.List;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.ReviewViewHolder> {
    private List<Review> reviewList;
    private FirebaseManager firebaseManager;

    public ReviewAdapter(List<Review> reviewList, FirebaseManager firebaseManager) {
        this.reviewList = reviewList;
        this.firebaseManager = firebaseManager;
    }

    public static class ReviewViewHolder extends RecyclerView.ViewHolder {
        public TextView reviewerName;
        public RatingBar reviewerRating;
        public TextView reviewText;

        public ReviewViewHolder(View itemView) {
            super(itemView);
            reviewerName = itemView.findViewById(R.id.reviewerName);
            reviewerRating = itemView.findViewById(R.id.reviewerRating);
            reviewText = itemView.findViewById(R.id.reviewText);
        }
    }

    @NonNull
    @Override
    public ReviewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Assicurati che il layout review_item.xml esista e sia corretto
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.review_item, parent, false);

        // Verifica se view è null dopo l'inflazione del layout
        if (view == null) {
            throw new IllegalArgumentException("Layout inflation failed: R.layout.review_item not found");
        }

        return new ReviewViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReviewViewHolder holder, int position) {
        Review review = reviewList.get(position);
        firebaseManager.getUserNameById(review.getReviewerId(), holder.reviewerName);
        holder.reviewerRating.setRating(review.getRating());
        holder.reviewText.setText(review.getReviewText());
    }

    @Override
    public int getItemCount() {
        return reviewList.size();
    }
}
