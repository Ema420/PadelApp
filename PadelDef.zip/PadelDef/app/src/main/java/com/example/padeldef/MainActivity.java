package com.example.padeldef;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    private FirebaseManager firebaseManager;
    private static final String TAG = "MainActivity";
    private DatabaseReference mDatabase;
    private Bundle userBundle;
    private boolean isAdmin = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        firebaseManager = new FirebaseManager();
        FirebaseUser currentUser = firebaseManager.getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        if (currentUser == null) {
            // L'utente non è loggato, avvia AuthenticationActivity
            Log.d(TAG, "Utente non autenticato, reindirizzamento all'AuthenticationActivity");
            Intent intent = new Intent(this, AuthenticationActivity.class);
            startActivity(intent);
            finish(); // Chiudi MainActivity per impedire all'utente di tornare indietro senza fare il login
            return; // Importante: esci dal metodo onCreate per evitare di caricare l'interfaccia utente
        }

        setContentView(R.layout.activity_main);
        bottomNavigationView = findViewById(R.id.bottom_navigation);

        loadUserData(currentUser.getUid());
        checkAdminStatus(currentUser.getUid());

        // Imposta l'elemento Home come predefinito
        loadFragment(new HomeFragment());

        // Imposta il listener per la barra di navigazione inferiore
        bottomNavigationView.setOnItemSelectedListener(item -> {
            Fragment fragment = null;
            int itemId = item.getItemId();

            if (itemId == R.id.menu_home) {
                fragment = new HomeFragment();
            } else if (itemId == R.id.menu_search) {
                fragment = new SearchFragment();
            } else if (itemId == R.id.menu_profile) {
                fragment = new ProfileFragment();
                fragment.setArguments(userBundle); // Imposta il Bundle come argomenti del Fragment
            } else if (itemId == R.id.menu_book_lesson) {
                if (isAdmin) {
                    fragment = new ManagerFragment();
                } else {

                    fragment = new BookLessonFragment();
                }
            }

            return loadFragment(fragment);
        });
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.replace(R.id.fragment_container, fragment);
            transaction.commit();
            return true;
        }
        return false;
    }

    private void loadUserData(String userId) {
        mDatabase.child("users").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    // L'utente esiste nel database
                    User user = dataSnapshot.getValue(User.class); // Assicurati di avere una classe User che corrisponda alla struttura dei tuoi dati

                    // Crea un Bundle per passare i dati al ProfileFragment
                    userBundle = new Bundle(); // Inizializza la variabile membro
                    userBundle.putString("userId", userId);
                    userBundle.putString("userEmail", user.getEmail()); // Assumi che la classe User abbia un metodo getEmail()
                    userBundle.putString("userName", user.getFirstName()); // Esempio: Assumi che tu abbia un campo "name" nel tuo database e un metodo getName() nella classe User
                    // Aggiungi altri dati dell'utente al Bundle se necessario

                    Log.d(TAG, "Dati utente caricati: " + user.getEmail());
                } else {
                    Log.d(TAG, "Utente non trovato nel database");
                    // Gestisci il caso in cui l'utente non esiste nel database (es. mostra un messaggio di errore)
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "Errore nel caricamento dei dati dell'utente: " + databaseError.getMessage());
                // Gestisci l'errore (es. mostra un messaggio di errore)
            }
        });
    }

    private void checkAdminStatus(String userId) {
        mDatabase.child("users").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    User user = dataSnapshot.getValue(User.class);
                    if (user != null && user.isAdmin()) {
                        // L'utente è un amministratore
                        isAdmin = true;
                        Log.d(TAG, "L'utente è un amministratore");
                    } else {
                        // L'utente non è un amministratore
                        isAdmin = false;
                        Log.d(TAG, "L'utente non è un amministratore");
                    }
                } else {
                    // L'utente non esiste nel database
                    isAdmin = false;
                    Log.d(TAG, "Utente non trovato nel database");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "Errore nel controllare lo stato di amministratore: " + databaseError.getMessage());
                // Gestisci l'errore (es. mostra un messaggio di errore)
            }
        });
    }

}
