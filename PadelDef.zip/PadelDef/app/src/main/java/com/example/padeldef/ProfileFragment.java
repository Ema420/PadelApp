package com.example.padeldef;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class ProfileFragment extends Fragment {

    private static final String TAG = "ProfileFragment";
    private String userId;
    private TextView profileUsername, profileEmail, profileBio, profileRanking, profileReputation;
    private ImageView profileImage;
    private FirebaseManager firebaseManager;
    private Button logoutButton; // Bottone per il logout
    private FirebaseAuth mAuth;

    private InvitationManager invitationManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        profileUsername = view.findViewById(R.id.profileUsername);
        profileEmail = view.findViewById(R.id.profileEmail);
        profileBio = view.findViewById(R.id.profileBio);
        profileRanking = view.findViewById(R.id.profileRanking);
        profileReputation = view.findViewById(R.id.profileReputation);
        profileImage = view.findViewById(R.id.profileImage);
        logoutButton = view.findViewById(R.id.logoutButton); // Inizializza il bottone di logout

        firebaseManager = new FirebaseManager();
        mAuth = FirebaseAuth.getInstance();

        invitationManager = new InvitationManager(getContext());

// Recupera l'ID utente dal Bundle
        Bundle bundle = getArguments();
        if (bundle != null) {
            userId = bundle.getString("userId");
            if (userId != null) {
                loadUserProfile(userId);
            } else {
                Log.e(TAG, "ID utente non trovato nel Bundle.");
            }
        } else {
            Log.e(TAG, "Bundle degli argomenti nullo.");
        }

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signOut();
            }
        });

        return view;
    }

    private void loadUserProfile(String userId) {
        firebaseManager.getUser(userId, new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user = dataSnapshot.getValue(User.class);
                if (user != null) {
                    displayUserProfile(user);
                } else {
                    Log.e(TAG, "Utente non trovato con ID: " + userId);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, "Errore nel caricamento del profilo utente: " + databaseError.getMessage());
            }
        });
    }

    private void displayUserProfile(User user) {
        profileUsername.setText(user.getFirstName() + " " + user.getLastName());
        profileEmail.setText(user.getEmail());
        profileBio.setText(user.getBio());
        profileRanking.setText("Ranking: " + user.getRanking());
        profileReputation.setText("Reputazione: " + user.getReputation());

// Carica l'immagine del profilo utilizzando Glide
        if (user.getProfileImageURL() != null && !user.getProfileImageURL().isEmpty()) {
            Glide.with(getContext())
                    .load(user.getProfileImageURL())
                    .placeholder(R.drawable.default_profile_image) // Immagine di placeholder
                    .error(R.drawable.error_profile_image) // Immagine di errore
                    .into(profileImage);
        } else {
            profileImage.setImageResource(R.drawable.default_profile_image); // Imposta l'immagine predefinita
        }
    }

    private void signOut() {
        mAuth.signOut();
// Dopo il logout, reindirizza l'utente alla schermata di login
        Intent intent = new Intent(getContext(), AuthenticationActivity.class); // Sostituisci LoginActivity.class con la tua activity di login
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        getActivity().finish(); // Chiude l'activity corrente
    }

    @Override
    public void onResume() {
        super.onResume();
        invitationManager.listenForInvitations();
    }

}
