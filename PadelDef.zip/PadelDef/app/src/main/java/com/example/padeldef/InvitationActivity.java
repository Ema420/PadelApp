package com.example.padeldef;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.padeldef.InvitationManager;
import com.example.padeldef.R;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class InvitationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.invitation_activity);

        String invitationId = getIntent().getStringExtra("invitationId");
        int courtNumber = getIntent().getIntExtra("courtNumber", -1);
        String bookingDateTime = getIntent().getStringExtra("bookingDateTime");

        TextView invitationDetails = findViewById(R.id.invitationDetails);
        Button acceptButton = findViewById(R.id.acceptButton);
        Button rejectButton = findViewById(R.id.rejectButton);

        SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        String formattedDateTime = bookingDateTime;

        invitationDetails.setText("Invito per il campo " + courtNumber + " il " + formattedDateTime);

        acceptButton.setOnClickListener(v -> {
            InvitationManager invitationManager = new InvitationManager(this);
            invitationManager.acceptInvitation(invitationId);
            finish();
        });

        rejectButton.setOnClickListener(v -> {
            InvitationManager invitationManager = new InvitationManager(this);
            invitationManager.rejectInvitation(invitationId);
            finish();
        });
    }
}