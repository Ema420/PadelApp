package com.example.padeldef;

import java.util.ArrayList;
import java.util.List;

public class Booking {
    private String bookingId;
    private String courtId;
    private String userId;
    private String bookingTime;
    private String status; // AVAILABLE, SEMI-BOOKED, BOOKED
    private List< String > invitedUserIds;

    public Booking() {
        // Required empty constructor for Firebase
    }

    public Booking(String courtId, String userId, String bookingTime) {
        this.courtId = courtId;
        this.userId = userId;
        this.bookingTime = bookingTime;
        this.status = "AVAILABLE";
        this.invitedUserIds = new ArrayList< >();
    }

    // Getter and setter methods for all fields
    public String getBookingId() {
        return bookingId;
    }
    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }
    public String getCourtId() {
        return courtId;
    }
    public void setCourtId(String courtId) {
        this.courtId = courtId;
    }
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    public String getBookingTime() {
        return bookingTime;
    }
    public void setBookingTime(String bookingTime) {
        this.bookingTime = bookingTime;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public List < String > getInvitedUserIds() {
        return invitedUserIds;
    }
    public void setInvitedUserIds(List < String > invitedUserIds) {
        this.invitedUserIds = invitedUserIds;
    }
}

