package com.example.padeldef;

public class Report {
    private String reporterId;
    private String reportedUserId;
    private String reportText;


    public Report() {
        // Default constructor required for Firebase
    }


    public Report(String reporterId, String reportedUserId, String reportText) {
        this.reporterId = reporterId;
        this.reportedUserId = reportedUserId;
        this.reportText = reportText;
    }


    public String getReporterId() {
        return reporterId;
    }


    public void setReporterId(String reporterId) {
        this.reporterId = reporterId;
    }


    public String getReportedUserId() {
        return reportedUserId;
    }


    public void setReportedUserId(String reportedUserId) {
        this.reportedUserId = reportedUserId;
    }


    public String getReportText() {
        return reportText;
    }


    public void setReportText(String reportText) {
        this.reportText = reportText;
    }
}
