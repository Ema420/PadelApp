package com.example.padeldef;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ManagerFragment extends Fragment {

    // UI elements
    private EditText clubNameEditText, clubLogoEditText, numCourtsEditText;
    private Button saveClubInfoButton, addCourtButton;
    private RecyclerView usersRecyclerView;
    private UserAdapter userAdapter;
    private List<User> userList;

    // Firebase
    private DatabaseReference mDatabase;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_manager, container, false);

        // Initialize UI elements
        clubNameEditText = view.findViewById(R.id.clubNameEditText);
        clubLogoEditText = view.findViewById(R.id.clubLogoEditText);
        saveClubInfoButton = view.findViewById(R.id.saveClubInfoButton);
        usersRecyclerView = view.findViewById(R.id.usersRecyclerView);

        // Initialize Firebase
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Initialize RecyclerView and Adapter
        userList = new ArrayList<>();
        userAdapter = new UserAdapter(userList, this::showUserDetails);
        usersRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        usersRecyclerView.setAdapter(userAdapter);

        // Load club info and users
        loadClubInfo();
        loadUsers();

        // Set click listeners
        saveClubInfoButton.setOnClickListener(v -> saveClubInfo());

        return view;
    }

    private void loadClubInfo() {
        mDatabase.child("clubInfo").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    ClubInfo clubInfo = dataSnapshot.getValue(ClubInfo.class);
                    if (clubInfo != null) {
                        clubNameEditText.setText(clubInfo.getName());
                        clubLogoEditText.setText(clubInfo.getLogoUrl());
                        numCourtsEditText.setText(String.valueOf(clubInfo.getNumCourts()));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("ManagerFragment", "Errore nel caricamento delle informazioni del circolo: " + databaseError.getMessage());
                Toast.makeText(getContext(), "Errore nel caricamento delle informazioni del circolo.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void saveClubInfo() {
        String clubName = clubNameEditText.getText().toString().trim();
        String clubLogo = clubLogoEditText.getText().toString().trim();
        int numCourts = 0;
        try {
            numCourts = Integer.parseInt(numCourtsEditText.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Numero di campi non valido.", Toast.LENGTH_SHORT).show();
            return;
        }

        ClubInfo clubInfo = new ClubInfo(clubName, clubLogo, numCourts);
        mDatabase.child("clubInfo").setValue(clubInfo)
                .addOnSuccessListener(aVoid -> Toast.makeText(getContext(), "Informazioni del circolo salvate con successo.", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> {
                    Log.e("ManagerFragment", "Errore nel salvataggio delle informazioni del circolo: " + e.getMessage());
                    Toast.makeText(getContext(), "Errore nel salvataggio delle informazioni del circolo.", Toast.LENGTH_SHORT).show();
                });
    }

    private void loadUsers() {
        mDatabase.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                userList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    User user = snapshot.getValue(User.class);
                    if (user != null) {
                        userList.add(user);
                    }
                }
                userAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("ManagerFragment", "Errore nel caricamento degli utenti: " + databaseError.getMessage());
                Toast.makeText(getContext(), "Errore nel caricamento degli utenti.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showUserDetails(User user) {
        // Implementa la logica per mostrare i dettagli dell'utente
        // Puoi mostrare un DialogFragment con i dettagli dell'utente e le azioni (modifica segnalazioni, sospensione, ban)
    }
}