package com.example.padeldef;


import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ManagerFragment extends Fragment {


    // UI elements
    private EditText clubNameEditText,
            clubLogoEditText,
            numCourtsEditText,
            instructorNameEditText;
    private Button saveClubInfoButton,
            addInstructorButton;
    private RecyclerView usersRecyclerView;
    private UserAdapter userAdapter;
    private List < User > userList;


    // Firebase
    private DatabaseReference mDatabase;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_manager, container, false);


        // Initialize UI elements
        clubNameEditText = view.findViewById(R.id.clubNameEditText);
        clubLogoEditText = view.findViewById(R.id.clubLogoEditText);
        saveClubInfoButton = view.findViewById(R.id.saveClubInfoButton);
        usersRecyclerView = view.findViewById(R.id.usersRecyclerView);
        instructorNameEditText = view.findViewById(R.id.instructorNameEditText); // New EditText for instructor name
        addInstructorButton = view.findViewById(R.id.addInstructorButton); // New Button for adding instructor


        // Initialize Firebase
        mDatabase = FirebaseDatabase.getInstance().getReference();


        // Initialize RecyclerView and Adapter
        userList = new ArrayList < > ();
        userAdapter = new UserAdapter(userList, this::showUserDetails);
        usersRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        usersRecyclerView.setAdapter(userAdapter);


        // Load club info and users
        loadClubInfo();
        loadUsers();


        // Set click listeners
        saveClubInfoButton.setOnClickListener(v -> saveClubInfo());
        addInstructorButton.setOnClickListener(v -> addInstructor()); // Set listener for adding instructor


        return view;
    }


    private void loadClubInfo() {
        mDatabase.child("clubInfo").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    ClubInfo clubInfo = dataSnapshot.getValue(ClubInfo.class);
                    if (clubInfo != null) {
                        clubNameEditText.setText(clubInfo.getName());
                        clubLogoEditText.setText(clubInfo.getLogoUrl());
                    }
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("ManagerFragment", "Errore nel caricamento delle informazioni del circolo: " + databaseError.getMessage());
                Toast.makeText(getContext(), "Errore nel caricamento delle informazioni del circolo.", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void saveClubInfo() {
        String clubName = clubNameEditText.getText().toString().trim();
        String clubLogo = clubLogoEditText.getText().toString().trim();
        ClubInfo clubInfo = new ClubInfo(clubName, clubLogo);
        mDatabase.child("clubInfo").setValue(clubInfo)
                .addOnSuccessListener(aVoid -> Toast.makeText(getContext(), "Informazioni del circolo salvate con successo.", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> {
                    Log.e("ManagerFragment", "Errore nel salvataggio delle informazioni del circolo: " + e.getMessage());
                    Toast.makeText(getContext(), "Errore nel salvataggio delle informazioni del circolo.", Toast.LENGTH_SHORT).show();
                });
    }


    private void addInstructor() {
        String instructorName = instructorNameEditText.getText().toString().trim();


        if (instructorName.isEmpty()) {
            Toast.makeText(getContext(), "Inserisci il nome dell'istruttore.", Toast.LENGTH_SHORT).show();
            return;
        }


        // Crea un nuovo ID per l'istruttore
        String instructorId = mDatabase.child("instructors").push().getKey();


        // Crea un oggetto Instructor
        Instructor instructor = new Instructor();
        instructor.setInstructorId(instructorId);
        instructor.setName(instructorName);
        instructor.setLessonsGiven(0); // Inizializza il numero di lezioni date a 0


        // Inizializza la disponibilità (esempio: tutti i giorni a tutte le ore sono disponibili)
        Map < String, Map < String, Boolean >> availability = new HashMap < > ();




        // Salva l'istruttore nel database
        mDatabase.child("instructors").child(instructorId).setValue(instructor)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(getContext(), "Istruttore aggiunto con successo.", Toast.LENGTH_SHORT).show();
                    instructorNameEditText.setText(""); // Pulisci il campo di input
                })
                .addOnFailureListener(e -> {
                    Log.e("ManagerFragment", "Errore nell'aggiunta dell'istruttore: " + e.getMessage());
                    Toast.makeText(getContext(), "Errore nell'aggiunta dell'istruttore.", Toast.LENGTH_SHORT).show();
                });
    }


    private void loadUsers() {
        mDatabase.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                userList.clear();
                for (DataSnapshot snapshot: dataSnapshot.getChildren()) {
                    User user = snapshot.getValue(User.class);
                    if (user != null) {
                        if(!user.isAdmin()) {
                            user.setUserId(snapshot.getKey());
                            userList.add(user);
                        }
                    }
                }
                userAdapter.notifyDataSetChanged();
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("ManagerFragment", "Errore nel caricamento degli utenti: " + databaseError.getMessage());
                Toast.makeText(getContext(), "Errore nel caricamento degli utenti.", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void showUserDetails(User user) {
        // Build the dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.user_details_dialog, null);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();


        // Get UI elements
        TextView reputationTextView = dialogView.findViewById(R.id.userReputationTextView);
        RecyclerView reportsRecyclerView = dialogView.findViewById(R.id.reportsRecyclerView);
        reportsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));


        // Load user reputation
        loadUserReputation(user.getUserId(), reputationTextView);


        // Load user reports
        loadUserReports(user.getUserId(), reportsRecyclerView);


        // Show the dialog
        dialog.show();
    }


    private void loadUserReputation(String userId, TextView reputationTextView) {
        mDatabase.child("users").child(userId).child("reputation")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            Double reputation = dataSnapshot.getValue(Double.class);
                            if (reputation != null) {
                                reputationTextView.setText("Reputazione: " + String.format("%.2f", reputation));
                            } else {
                                reputationTextView.setText("Reputazione: Non disponibile");
                            }
                        } else {
                            reputationTextView.setText("Reputazione: Non disponibile");
                        }
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e("ManagerFragment", "Errore nel caricamento della reputazione: " + databaseError.getMessage());
                        reputationTextView.setText("Reputazione: Errore nel caricamento");
                    }
                });
    }


    private void loadUserReports(String userId, RecyclerView reportsRecyclerView) {
        DatabaseReference reportsRef = FirebaseDatabase.getInstance().getReference("reports");
        reportsRef.orderByChild("reportedUserId").equalTo(userId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        List < Report > reportsList = new ArrayList < > ();
                        for (DataSnapshot snapshot: dataSnapshot.getChildren()) {
                            Report report = snapshot.getValue(Report.class);
                            if (report != null) {
                                reportsList.add(report);
                            }
                        }


                        ReportAdapter reportAdapter = new ReportAdapter(reportsList);
                        reportsRecyclerView.setAdapter(reportAdapter);
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e("ManagerFragment", "Errore nel caricamento delle segnalazioni: " + databaseError.getMessage());
                        Toast.makeText(getContext(), "Errore nel caricamento delle segnalazioni.", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
